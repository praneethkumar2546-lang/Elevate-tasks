
const express = require("express");

const app = express();

app.use(express.json());

let books = [
    { id: 1, title: "The Alchemist", author: "Paulo Coelho" },
    { id: 2, title: "Wings of Fire", author: "A.P.J. Abdul Kalam" }
];

let nextId = 3;

app.get("/", (req, res) => {
    res.send("Book REST API is running!");
});

app.get("/books", (req, res) => {
    res.status(200).json(books);
});

app.get("/books/:id", (req, res) => {
    const id = Number(req.params.id);
    const book = books.find(book => book.id === id);

    if (!book) {
        return res.status(404).json({ message: "Book not found" });
    }

    res.json(book);
});

app.post("/books", (req, res) => {
    const { title, author } = req.body;

    if (
        typeof title !== "string" || !title.trim() ||
        typeof author !== "string" || !author.trim()
    ) {
        return res.status(400).json({
            message: "Title and author are required"
        });
    }

    const newBook = {
        id: nextId++,
        title: title.trim(),
        author: author.trim()
    };

    books.push(newBook);

    res.status(201).json({
        message: "Book added successfully",
        book: newBook
    });
});

app.put("/books/:id", (req, res) => {
    const id = Number(req.params.id);
    const book = books.find(book => book.id === id);

    if (!book) {
        return res.status(404).json({ message: "Book not found" });
    }

    const { title, author } = req.body;

    if (
        typeof title !== "string" || !title.trim() ||
        typeof author !== "string" || !author.trim()
    ) {
        return res.status(400).json({
            message: "Title and author are required"
        });
    }

    book.title = title.trim();
    book.author = author.trim();

    res.json({
        message: "Book updated successfully",
        book
    });
});

app.delete("/books/:id", (req, res) => {
    const id = Number(req.params.id);
    const index = books.findIndex(book => book.id === id);

    if (index === -1) {
        return res.status(404).json({ message: "Book not found" });
    }

    const deletedBook = books.splice(index, 1)[0];

    res.json({
        message: "Book deleted successfully",
        book: deletedBook
    });
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
